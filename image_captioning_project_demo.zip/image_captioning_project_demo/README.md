# Image Captioning Project (Demo)

This is a lightweight, end-to-end demo project you can run locally or adapt to your own dataset/model.

## Project Structure
```
image_captioning_project_demo/
├── data/
│   ├── raw/                # sample images (add your own here)
│   ├── processed/          # any preprocessed artifacts go here
│   └── vocab/              # saved vocabulary files
├── models/
│   ├── trained_model.pkl   # (optional) your trained model file
│   └── checkpoints/        # training checkpoints
├── scripts/
│   ├── build_vocab.py      # create/update vocab from a dataset
│   ├── train.py            # train your model (placeholder/demo)
│   └── test.py             # evaluate your model (placeholder/demo)
├── streamlit_app.py        # main Streamlit app for inference
├── requirements.txt        # Python dependencies
├── config.yaml             # config for paths + hyperparameters
└── README.md
```

## Quickstart (Windows CMD)
```cmd
cd image_captioning_project_demo
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
streamlit run streamlit_app.py
```

Open the shown URL (e.g., http://localhost:8501) in your browser.

## Notes
- This demo uses a **rule-based captioner** for simplicity (no heavy model).
- Replace it with your PyTorch model by saving it under `models/` and loading in `streamlit_app.py`.
- Use the scripts inside `scripts/` as starting points for your own training pipeline.
