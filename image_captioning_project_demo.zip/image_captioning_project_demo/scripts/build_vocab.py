import os, json, pickle, re
from collections import Counter
from pathlib import Path

DATA_DIR = Path('data')
VOCAB_PATH = DATA_DIR/'vocab'/'vocab.pkl'
RAW_DIR = DATA_DIR/'raw'

def tokenize(text):
    return re.findall(r"[a-z']+", text.lower())

def main():
    # Dummy corpus from filenames for demo
    corpus = ' '.join([p.stem.replace('_',' ') for p in RAW_DIR.glob('*.jpg')])
    tokens = tokenize(corpus)
    cnt = Counter(tokens)
    base_tokens = ['<pad>', '<start>', '<end>', '<unk>']
    words = base_tokens + [w for w,c in cnt.most_common(5000) if w not in base_tokens]
    word2idx = {w:i for i,w in enumerate(words)}
    idx2word = {i:w for w,i in word2idx.items()}

    VOCAB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(VOCAB_PATH, 'wb') as f:
        pickle.dump({'word2idx': word2idx, 'idx2word': idx2word}, f)
    print(f"Saved vocab with {len(words)} tokens to {VOCAB_PATH}")

if __name__ == '__main__':
    main()
