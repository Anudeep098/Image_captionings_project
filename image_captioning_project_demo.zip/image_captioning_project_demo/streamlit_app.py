import streamlit as st
from PIL import Image
import pickle, io, random, os

st.set_page_config(page_title="Image Captioning (Demo)", page_icon="🖼️", layout="centered")
st.title("🖼️ Image Captioning – Demo App")
st.write("Upload an image and generate a simple caption (rule-based demo). Replace with your model later.")

# Load vocab (demo)
with open("data/vocab/vocab.pkl", "rb") as f:
    vocab = pickle.load(f)
word2idx = vocab["word2idx"]
idx2word = vocab["idx2word"]

def rule_based_caption(img):
    # Simple demo captions
    subjects = ["a man", "a woman", "a child", "a dog", "a cat"]
    verbs = ["is", "is", "is", "is", "is"]
    actions = ["standing", "sitting", "playing", "walking", "looking"]
    places = ["in the park", "on the street", "at the beach", "near a bicycle", "with a ball"]
    return f"{random.choice(subjects)} {random.choice(verbs)} {random.choice(actions)} {random.choice(places)}."

uploaded = st.file_uploader("Upload an image", type=["jpg","jpeg","png"])

col1, col2 = st.columns(2)
with col1:
    st.subheader("Input Image")
    if uploaded:
        image = Image.open(uploaded).convert("RGB")
    else:
        image = Image.open("data/raw/sample.jpg").convert("RGB")
    st.image(image, use_column_width=True)

with col2:
    st.subheader("Generated Caption")
    if st.button("Generate Caption"):
        cap = rule_based_caption(image)
        st.success(cap)
    else:
        st.info("Click **Generate Caption** to see a caption.")

st.markdown("---")
st.caption("This is a lightweight demo. Plug in your real model in place of the rule-based captioner.")
